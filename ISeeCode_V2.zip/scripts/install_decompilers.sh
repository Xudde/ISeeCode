#!/usr/bin/env bash
# 反编译工具一键安装脚本（升级阶段 2）
# 支持环境：Kali / Debian / Ubuntu；工具统一放 tools/decompilers/
# 已配置：cfr(Java 反编译)、jadx(APK/DEX)、apktool(APK 资源)
# 可选：ilspycmd(.NET，需 dotnet-sdk)、pycdc(.pyc，需编译)
set -e
DIR="$(cd "$(dirname "$0")/.." && pwd)/tools/decompilers"
mkdir -p "$DIR"

echo "== [1/5] 检查 Java 运行时 =="
if ! command -v java >/dev/null; then
  echo "安装 openjdk-17-jdk ..."
  apt-get update -qq && apt-get install -y -qq openjdk-17-jdk-headless
fi

echo "== [2/5] cfr（jar/war/class → Java 源码）=="
if [ ! -s "$DIR/cfr.jar" ]; then
  curl -sL --retry 3 -o "$DIR/cfr.jar" \
    "https://repo1.maven.org/maven2/org/benf/cfr/0.152/cfr-0.152.jar" \
  || curl -sL --retry 3 -o "$DIR/cfr.jar" \
    "https://github.com/leibnitz27/cfr/releases/download/0.152/cfr-0.152.jar"
fi
java -jar "$DIR/cfr.jar" --version 2>/dev/null | head -1 || echo "WARN: cfr 下载校验失败"

echo "== [3/5] jadx（apk/dex → Java 源码）=="
if [ ! -x "$DIR/jadx/bin/jadx" ]; then
  curl -sL --retry 3 -o /tmp/jadx.zip \
    "https://github.com/skylot/jadx/releases/download/v1.5.0/jadx-1.5.0.zip"
  rm -rf "$DIR/jadx" && mkdir -p "$DIR/jadx"
  unzip -qo /tmp/jadx.zip -d "$DIR/jadx" && chmod +x "$DIR/jadx/bin/jadx" || echo "WARN: jadx 解压失败"
fi
"$DIR/jadx/bin/jadx" --version 2>/dev/null || echo "WARN: jadx 不可用"

echo "== [4/5] apktool（APK 资源/manifest，可选）=="
if [ ! -s "$DIR/apktool.jar" ]; then
  curl -sL --retry 3 -o "$DIR/apktool.jar" \
    "https://github.com/iBotPeaches/Apktool/releases/download/v2.9.3/apktool_2.9.3.jar" || true
fi

echo "== [5/5] 可选工具 =="
# .NET 反编译：需要 dotnet-sdk（Kali: apt install dotnet-sdk；或参考 https://dot.net）
command -v dotnet >/dev/null && { dotnet tool install --global ilspycmd 2>/dev/null || true; } \
  || echo "SKIP: ilspycmd 需先安装 dotnet-sdk（.NET 审计将走降级扫描）"
# pyc 反编译：pycdc 需 cmake/g++ 编译，或使用 pypi 的 decompyle3（仅 3.8 字节码）
pip3 install -q decompyle3 2>/dev/null || echo "SKIP: decompyle3（.pyc 审计将走降级扫描）"

echo
echo "== 工具状态 =="
for f in cfr.jar apktool.jar; do
  [ -s "$DIR/$f" ] && echo "OK  $f ($(stat -c%s "$DIR/$f") bytes)" || echo "MISS $f"
done
[ -x "$DIR/jadx/bin/jadx" ] && echo "OK  jadx" || echo "MISS jadx"
command -v ilspycmd >/dev/null && echo "OK  ilspycmd" || echo "MISS ilspycmd（降级：字符串特征扫描）"
command -v pycdc >/dev/null && echo "OK  pycdc" || { command -v decompyle3 >/dev/null && echo "OK  decompyle3" || echo "MISS pycdc/decompyle3（降级：字符串特征扫描）"; }
echo "安装完成。"
