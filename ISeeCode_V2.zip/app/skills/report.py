"""报告生成 skill：输出自包含 HTML 可视化审计报告（附带 Markdown 版）"""
import html
from datetime import datetime
from pathlib import Path

from app.audit_labels import vuln_label
from app.config import REPORT_DIR

SEVERITY_ORDER = {"CRITICAL": 0, "ERROR": 0, "HIGH": 0, "WARNING": 1, "MEDIUM": 1, "INFO": 2, "LOW": 2}
SEVERITY_COLORS = {
    "CRITICAL": "#d63031", "ERROR": "#d63031", "HIGH": "#e17055",
    "WARNING": "#fdcb6e", "MEDIUM": "#fdcb6e",
    "INFO": "#74b9ff", "LOW": "#74b9ff",
}

_PAGE_CSS = """\
:root{--bg:#f4f6fb;--card:#fff;--ink:#1e272e;--muted:#7f8c9b;--line:#e8ecf3;--brand:#0a66c2;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--ink);line-height:1.6;padding:32px 16px}
.wrap{max-width:1000px;margin:0 auto}
h1{font-size:24px}
h2{font-size:17px;margin:28px 0 12px;padding-left:10px;border-left:4px solid var(--brand)}
.hero{background:linear-gradient(135deg,#0a66c2,#1e90ff);color:#fff;border-radius:12px;padding:24px 28px;margin-bottom:20px}
.hero h1{margin-bottom:8px}
.hero .meta{font-size:13px;opacity:.92}
.hero .meta span{margin-right:18px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:18px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;text-align:center}
.card .num{font-size:26px;font-weight:700}
.card .lbl{font-size:12px;color:var(--muted);margin-top:2px}
.card.ok .num{color:#00a86b}.card.bad .num{color:#d63031}.card.warn .num{color:#e17055}.card.info .num{color:#0a66c2}
.vuln{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px 20px;margin-bottom:14px}
.vuln .head{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.vuln .idx{font-size:13px;color:var(--muted)}
.badge{color:#fff;font-size:12px;font-weight:600;padding:2px 10px;border-radius:10px;letter-spacing:.5px}
.badge.poc{background:#00a86b}.badge.nopoc{background:#e0e4ec;color:#555}
.vuln .rule{font-size:15px;font-weight:600}
.vuln .kv{display:grid;grid-template-columns:auto 1fr;gap:4px 14px;font-size:13px;margin:12px 0}
.vuln .kv b{color:var(--muted);font-weight:600;min-width:72px}
pre.code{background:#1e272e;color:#a5f3b0;border-radius:8px;padding:12px 14px;font-size:12.5px;overflow-x:auto;white-space:pre;margin-top:10px;font-family:ui-monospace,Consolas,"Courier New",monospace}
.payload{background:#fff8e1;border:1px dashed #f0c14b;border-radius:8px;padding:8px 12px;font-size:12.5px;word-break:break-all;margin-top:8px}
.result{background:#eef9f2;border-left:4px solid #00a86b;padding:8px 12px;border-radius:6px;font-size:13px;margin-top:8px}
.result.no{border-color:#d63031;background:#fdecec}
.reason{background:#f6f8fc;border-radius:8px;padding:10px 12px;font-size:13px;margin-top:10px;border-left:4px solid #0a66c2}
.evidence{background:#f0f7f0;border-left:4px solid #00a86b;border-radius:8px;padding:10px 12px;font-size:13px;margin-top:10px}
.evidence pre{white-space:pre-wrap;font-size:12px;margin-top:6px;font-family:ui-monospace,Consolas,monospace}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden;font-size:13px}
th,td{padding:9px 12px;text-align:left;border-bottom:1px solid var(--line)}
th{background:#fafbfd;color:var(--muted);font-weight:600}
tr:last-child td{border-bottom:none}
.pill{display:inline-block;font-size:11.5px;padding:1px 8px;border-radius:8px;font-weight:600}
.pill.verified{background:#e2f5ec;color:#00a86b}.pill.fp{background:#fdecec;color:#d63031}
.pill.na{background:#eef1f5;color:var(--muted)}
.pill.ok{background:#e2f5ec;color:#00a86b}.pill.no{background:#fdecec;color:#d63031}.pill.dash{background:#eef1f5;color:var(--muted)}
.empty{background:var(--card);border:1px dashed var(--line);border-radius:10px;padding:28px;text-align:center;color:var(--muted)}
footer{text-align:center;color:var(--muted);font-size:12px;margin-top:36px}
"""


def _sev_badge(sev: str) -> str:
    color = SEVERITY_COLORS.get((sev or "").upper(), "#636e72")
    return f'<span class="badge" style="background:{color}">{html.escape((sev or "N/A").upper())}</span>'


def _poc_badge(v: dict) -> str:
    if v.get("poc_verified") is True:
        return '<span class="badge poc">✅ POC 已复现</span>'
    if v.get("poc_verified") is False:
        return '<span class="badge nopoc">❌ POC 未复现</span>'
    return '<span class="badge nopoc">— 未验证</span>'


def _judge_pill(v: dict) -> str:
    status = v.get("agent_status")
    if v.get("llm_is_real") is True or status == "verified":
        return '<span class="pill verified">Agent 确认真实</span>'
    if v.get("llm_is_real") is False or status == "false_positive":
        return '<span class="pill fp">误报</span>'
    return '<span class="pill na">未研判</span>'


def _poc_pill(v: dict) -> str:
    if v.get("poc_verified") is True:
        return '<span class="pill ok">✅</span>'
    if v.get("poc_verified") is False:
        return '<span class="pill no">❌</span>'
    return '<span class="pill dash">—</span>'


def _vuln_card(i: int, v: dict) -> str:
    snippet = html.escape((v.get("code_snippet") or "").strip()[:800])
    payload = html.escape(v.get("poc_payload") or "")
    verify = html.escape(v.get("verify_result") or "")
    evidence = v.get("agent_evidence") or ""
    reason = v.get("llm_reason") or v.get("agent_reason") or ""
    confidence = v.get("agent_confidence") or v.get("llm_confidence") or "-"
    poc_cls = "result" + ("" if v.get("poc_verified") is True else " no")
    parts = [
        '<div class="vuln">',
        '<div class="head">',
        f'<span class="idx">#{i}</span>{_sev_badge(v.get("severity",""))}{_judge_pill(v)}{_poc_badge(v)}',
        f'<span class="rule" title="{html.escape(v.get("rule_id",""))}">{html.escape(vuln_label(v.get("rule_id","")))}</span>',
        "</div>",
        '<div class="kv">',
        f"<b>位置</b><span>{html.escape(v.get('file_path',''))}:{v.get('line','')}</span>",
        f"<b>置信度</b><span>{html.escape(str(confidence))}</span>",
        "</div>",
    ]
    if reason:
        parts.append(f'<div class="reason"><b>研判理由：</b>{html.escape(reason)}</div>')
    if payload:
        parts.append(f'<div class="payload"><b>POC Payload：</b><code>{payload}</code></div>')
    if verify:
        parts.append(f'<div class="{poc_cls}"><b>动态验证结果：</b>{verify}</div>')
    if evidence:
        parts.append(f'<div class="evidence"><b>Agent 证据链：</b><pre>{html.escape(evidence)}</pre></div>')
    parts.append(f'<pre class="code">{snippet}</pre>')
    parts.append("</div>")
    return "\n".join(parts)


def run_report(task, vulns: list[dict]) -> str:
    """生成自包含 HTML 报告（主）与 Markdown 报告（副），返回 HTML 文件路径"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _real(v):
        return v.get("llm_is_real") is True or v.get("agent_status") == "verified"

    def _fp(v):
        return v.get("llm_is_real") is False or v.get("agent_status") == "false_positive"

    real = [v for v in vulns if _real(v)]
    false_positive = [v for v in vulns if _fp(v)]
    unjudged = [v for v in vulns if not _real(v) and not _fp(v)]
    poc_passed = [v for v in vulns if v.get("poc_verified") is True]
    real.sort(key=lambda v: SEVERITY_ORDER.get((v.get("severity") or "").upper(), 3))

    sev_rows = "".join(
        f'<tr><td>{i}</td><td>{_sev_badge(v["severity"])}</td>'
        f'<td title="{html.escape(v["rule_id"])}">{html.escape(vuln_label(v["rule_id"]))}</td>'
        f'<td><code>{html.escape(v["file_path"])}:{v["line"]}</code></td>'
        f'<td>{_judge_pill(v)}</td><td>{_poc_pill(v)}</td></tr>'
        for i, v in enumerate(vulns, 1)
    ) or '<tr><td colspan="6" style="color:var(--muted)">无静态扫描结果</td></tr>'

    vuln_cards = "\n".join(_vuln_card(i, v) for i, v in enumerate(real, 1))
    vuln_section = (
        f"<h2>真实漏洞明细（{len(real)}）</h2>"
        + (vuln_cards if vuln_cards else '<div class="empty">未发现经确认的真实漏洞。</div>')
    )

    html_out = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>审计报告 - {html.escape(task.filename)}</title>
<style>{_PAGE_CSS}</style>
</head>
<body>
<div class="wrap">
  <div class="hero">
    <h1>🛡️ 源码自动化审计报告</h1>
    <div class="meta">
      <span>任务 ID：#{task.id}</span>
      <span>源码包：{html.escape(task.filename)}</span>
      <span>技术栈：{html.escape(task.tech_stack)}</span>
      <span>生成时间：{now}</span>
    </div>
  </div>

  <div class="cards">
    <div class="card info"><div class="num">{len(vulns)}</div><div class="lbl">静态扫描发现</div></div>
    <div class="card bad"><div class="num">{len(real)}</div><div class="lbl">Agent 确认真实</div></div>
    <div class="card warn"><div class="num">{len(false_positive)}</div><div class="lbl">误报（Agent 排除）</div></div>
    <div class="card"><div class="num">{len(unjudged)}</div><div class="lbl">未经研判</div></div>
    <div class="card ok"><div class="num">{len(poc_passed)}</div><div class="lbl">POC 验证通过</div></div>
  </div>

  {vuln_section}

  <h2>静态扫描全量结果（{len(vulns)}）</h2>
  <table>
    <thead><tr><th>#</th><th>严重性</th><th>规则</th><th>位置</th><th>研判</th><th>POC</th></tr></thead>
    <tbody>{sev_rows}</tbody>
  </table>

  <footer>由源码自动化审计平台生成 · {now}</footer>
</div>
</body>
</html>
"""
    out = REPORT_DIR / f"task_{task.id}_report.html"
    out.write_text(html_out, encoding="utf-8")

    # Markdown 版（便于复制/存档）
    def _mk(flag):
        return {True: "✅", False: "❌", None: "—"}.get(flag if flag is not None else None)

    lines = [
        f"# 源码自动化审计报告",
        "",
        f"- **任务 ID**：{task.id}",
        f"- **源码包**：{task.filename}",
        f"- **技术栈**：{task.tech_stack}",
        f"- **生成时间**：{now}",
        "",
        "## 概览",
        "",
        "| 指标 | 数量 |",
        "| --- | --- |",
        f"| 静态扫描发现 | {len(vulns)} |",
        f"| Agent 确认真实 | {len(real)} |",
        f"| 误报（Agent 排除） | {len(false_positive)} |",
        f"| 未经研判 | {len(unjudged)} |",
        f"| POC 验证通过 | {len(poc_passed)} |",
        "",
        "## 真实漏洞明细（按严重性排序）",
        "",
    ]
    if not real:
        lines.append("未发现经确认的真实漏洞。")
    for i, v in enumerate(real, 1):
        poc_mark = "✅ 已复现" if v.get("poc_verified") is True else ("❌ 未复现" if v.get("poc_verified") is False else "—")
        reason = v.get("llm_reason") or v.get("agent_reason") or "-"
        evidence = v.get("agent_evidence") or ""
        lines += [
            f"### {i}. [{v['severity']}] {vuln_label(v['rule_id'])} (`{v['rule_id']}`)",
            "",
            f"- **位置**：`{v['file_path']}:{v['line']}`",
            f"- **置信度**：{v.get('agent_confidence') or v.get('llm_confidence') or '-'}",
            f"- **研判理由**：{reason}",
            f"- **POC 验证**：{poc_mark}{('：' + v.get('verify_result')) if v.get('verify_result') else ''}",
            f"- **POC Payload**：`{v.get('poc_payload') or '—'}`",
        ]
        if evidence:
            lines.append("")
            lines.append("**Agent 证据链**：")
            lines.append("```")
            lines.append(evidence)
            lines.append("```")
        lines += ["", "```", v["code_snippet"].strip()[:500], "```", ""]
    lines += ["## 静态扫描全量结果", "",
              "| # | 严重性 | 规则 | 位置 | 研判 | POC |", "| --- | --- | --- | --- | --- | --- |"]
    for i, v in enumerate(vulns, 1):
        judge = "Agent 确认" if _real(v) else ("误报" if _fp(v) else "未研判")
        poc_mark = _mk(v.get("poc_verified"))
        lines.append(f"| {i} | {v['severity']} | {vuln_label(v['rule_id'])} | `{v['file_path']}:{v['line']}` | {judge} | {poc_mark} |")

    md_out = out.with_suffix(".md")
    md_out.write_text("\n".join(lines), encoding="utf-8")
    return str(out)
