"""LLM 误报研判 skill：调用兼容 OpenAI 协议的 LLM 判断漏洞真实性"""
import json

from app.models import Config
from sqlalchemy.orm import Session


def get_llm_config(db: Session) -> dict | None:
    """读取 LLM 配置，未配置完整则返回 None（跳过研判）"""
    rows = {c.key: c.value for c in db.query(Config).all()}
    base_url = rows.get("base_url", "")
    api_key = rows.get("api_key", "")
    model = rows.get("model", "")
    if not (base_url and api_key and model):
        return None
    return {"base_url": base_url, "api_key": api_key, "model": model}


SYSTEM_PROMPT = (
    "你是资深代码安全审计专家。给定静态扫描发现的漏洞信息（规则、代码片段、说明），"
    "判断该漏洞是否为真实漏洞而非误报。只输出 JSON，格式："
    '{"is_real": true/false, "reason": "简要理由（中文，100字内）", "confidence": "high/medium/low"}'
)


def judge_vulns(vulns: list[dict], llm_cfg: dict, task_log) -> None:
    """对每条漏洞逐条调用 LLM 研判，就地写入 llm_is_real / llm_reason / llm_confidence"""
    from openai import OpenAI

    client = OpenAI(base_url=llm_cfg["base_url"], api_key=llm_cfg["api_key"], timeout=60)
    for v in vulns:
        user_msg = (
            f"规则: {v['rule_id']}\n严重性: {v['severity']}\n"
            f"文件: {v['file_path']}:{v['line']}\n"
            f"代码片段:\n{v['code_snippet']}\n"
            f"扫描器说明: {v.get('message', '')}"
        )
        try:
            resp = client.chat.completions.create(
                model=llm_cfg["model"],
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                temperature=0,
            )
            text = resp.choices[0].message.content.strip()
            # 容错解析：提取第一个 JSON 对象
            if text.startswith("```"):
                text = text.split("```")[1].lstrip("json\r\n")
            result = json.loads(text[text.find("{"): text.rfind("}") + 1])
            # 严格类型校验：LLM 输出 "false"/"true" 字符串时不得误判
            is_real = result.get("is_real")
            v["llm_is_real"] = is_real if isinstance(is_real, bool) else None
            v["llm_reason"] = str(result.get("reason", ""))[:500]
            v["llm_confidence"] = str(result.get("confidence", "low"))[:8]
        except Exception as e:  # 单条失败不影响整体
            v["llm_is_real"] = None
            v["llm_reason"] = f"LLM 研判失败: {e}"[:500]
            v["llm_confidence"] = "low"
